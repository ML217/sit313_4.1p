import React from 'react';
import { Card, Image, Rating, Header } from 'semantic-ui-react';
import articles from '../data/articles'; // Make sure this file exists

const FeaturedArticles = () => {
  return (
    <div style={{ padding: '2em' }}>
      <Header as="h2" textAlign="center">Featured Articles</Header>
      <Card.Group itemsPerRow={3} stackable>
        {articles.map(article => (
          <Card key={article.id}>
            <Image src={article.image} wrapped ui={false} />
            <Card.Content>
              <Card.Header>{article.title}</Card.Header>
              <Card.Meta>{article.author}</Card.Meta>
              <Card.Description>{article.description}</Card.Description>
            </Card.Content>
            <Card.Content extra>
              <Rating icon="star" defaultRating={article.rating} maxRating={5} disabled />
            </Card.Content>
          </Card>
        ))}
      </Card.Group>
    </div>
  );
};

export default FeaturedArticles;